import React from "react";
import { FiShoppingCart } from 'react-icons/fi';

const Cart = (props) => {
    return (
    <div>
        <p>soy un carrito</p>    
        <FiShoppingCart/>
    </div>    
    )
}
console.log(Cart); 
export default Cart;